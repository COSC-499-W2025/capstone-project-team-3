// File: src/com/mycompany/app/MainApp.java

package com.mycompany.app;

// Standard Java library imports
import java.util.List;
import java.util.ArrayList;
import java.io.File;

// External library imports (e.g., from a dependency)
import org.apache.commons.lang3.StringUtils;

// Internal project imports (from the same project)
import com.mycompany.app.utils.MathUtils;
import com.mycompany.app.services.DataService;
import com.mycompany.app.models.User;

// Static import of a constant
import static com.mycompany.app.constants.AppConstants.VERSION;

public class MainApp {

    /**
     * Application entry point. 
     * Demonstrates basic usage of collections, external libraries, internal classes, and prints the app version.
     *
     * @param args command-line arguments
     */
    public static void main(String[] args) {
        // Using standard library classes
        List<String> users = new ArrayList<>();
        
        // Using external library
        String joined = StringUtils.join(users, ", ");
        
        // Using internal classes
        User user = new User("Alice");
        MathUtils math = new MathUtils();
        DataService service = new DataService();
        
        // Using static import
        System.out.println("App version: " + VERSION);
    }

    /** Doc for Foo */
        class Foo {}
}

interface Util {
    static void help() {
        System.out.println("Help!");
    }
}
