// File: MainApp.cpp

#include <iostream>     // Standard library: for std::cout
#include <vector>       // Standard library: for std::vector
#include <string>       // Standard library: for std::string
#include <algorithm>    // Standard library: for std::join-like operations (if needed)

// Example internal includes (could be your own classes)
#include "User.h"
#include "MathUtils.h"
#include "DataService.h"

// Static constant example
const std::string VERSION = "1.0.0";

class MainApp {
public:
    /**
     * Application entry point.
     * Demonstrates usage of standard libraries, internal classes, and prints the app version.
     */
    void run() {
        // Using standard library classes
        std::vector<std::string> users;

        // Example of creating internal objects
        User user("Alice");
        MathUtils math;
        DataService service;

        // Print version
        std::cout << "App version: " << VERSION << std::endl;
    }
    // fubru
};

int main() {
    MainApp app;
    app.run();
    return 0;
}
