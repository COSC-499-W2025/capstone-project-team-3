using System;
using System.Collections.Generic;

namespace TreeSitterMapper
{
    public static class LanguageMapper
    {
        // Base mapping from detected (Pygments-like) names to Tree-sitter language names
        private static readonly Dictionary<string, string> _tsLanguageMapping = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase)
        {
            { "Matlab", "matlab" },
            { "Objective-C", "objc" },
            { "C++", "cpp" },
            { "Python", "python" },
            { "JavaScript", "javascript" }
        };

        /// <summary>
        /// Maps a detected language name to its Tree-sitter equivalent, case-insensitively.
        /// </summary>
        /// <param name="language">The input language name (e.g., "MATLAB", "Python").</param>
        /// <returns>The Tree-sitter compatible name, or the normalized lowercase name if not found.</returns>
        public static string MapLanguageForTreeSitter(string language)
        {
            if (string.IsNullOrWhiteSpace(language))
                return language;

            string normalized = language.Trim();

            if (_tsLanguageMapping.TryGetValue(normalized, out string mapped))
            {
                return mapped;
            }

            // Default fallback: return lowercase normalized version
            return normalized.ToLowerInvariant();
        }

        // Example usage
        public static void Main(string[] args)
        {
            string[] testInputs = { "MATLAB", "matLab", "Objective-C", "C++", "UnknownLang" };

            foreach (var lang in testInputs)
            {
                string mapped = MapLanguageForTreeSitter(lang);
                Console.WriteLine($"{lang} → {mapped}");
            }
        }
    }
}
