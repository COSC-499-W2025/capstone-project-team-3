<script setup>
defineProps({ color: String, size: String });
const count = ref(0);
onMounted(() => console.log('mounted'));
</script>

<template>
  <button>{{ count }}</button>
</template>
