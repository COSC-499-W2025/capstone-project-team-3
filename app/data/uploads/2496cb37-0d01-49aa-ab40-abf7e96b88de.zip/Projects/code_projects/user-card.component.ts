import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-card',
  template: `
    <div>
      <h2>{{ userName }}</h2>
      <p>Likes: {{ likes }}</p>
      <button (click)="like()">Like</button>
    </div>
  `
})
export class UserCardComponent implements OnInit {
  @Input() userName: string;          // prop
  @Input() initialLikes: number;      // prop

  likes: number;                       // state variable

  ngOnInit() {
    this.likes = this.initialLikes;    // lifecycle hook
  }

  like() {
    this.likes++;
  }
}
