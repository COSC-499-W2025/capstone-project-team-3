# This is a sample change that has changed the world repeatedly 

How to take over the world
1. Buy Bitcoin
2. Lose billion of dollars
3. Pretend it was a mistake
4. Profit

