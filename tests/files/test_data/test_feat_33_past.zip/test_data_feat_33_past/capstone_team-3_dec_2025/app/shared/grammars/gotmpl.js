const make_grammar = require('./make_grammar')

module.exports = make_grammar('gotmpl')
