Most of the implementation for parsing code files was extracted using the Tree sitter library

In generating the grammars.js file specific to each language, I extracted list of Parsers from Tree sitter list of parsers: https://github.com/tree-sitter/tree-sitter/wiki/List-of-parsers