Common files:

webgl-utils.js: standard utilities from google to set up a webgl context

MV.js: our matrix/vector package. Documentation on website

initShaders.js: functions to initialize shaders in the html file

initShaders2.js: functions to initialize shaders that are in separate files