
 WikipediaThe Free Encyclopedia

Search
Donate
Create account
Log in

Wikipedia began as an impossible dream. Today, we celebrate 25 years of humanity at its best. Join us
Contents  hide
(Top)
Description
History

Etymology
Composition

Cultivars

Cultivation

Pests and diseases

Production
Culinary use

In human culture
See also
References
External links
Orange (fruit)

143 languages
Article
Talk
Read
View source
View history

Tools
Appearance  hide
Text

Small

Standard

Large
Width

Standard

Wide
Color (beta)

Automatic

Light

Dark
This is a good article. Click here for more information.
Page semi-protected
From Wikipedia, the free encyclopedia
"Orange peel" redirects here. For other uses, see Orange peel (disambiguation).

Orange—whole, halved, and peeled segment
The orange, also called sweet orange to distinguish it from the bitter orange (Citrus × aurantium), is the fruit of a tree in the family Rutaceae. Botanically, this is the hybrid Citrus × sinensis, between the pomelo (Citrus maxima) and the mandarin orange (Citrus reticulata). The chloroplast genome, and therefore the maternal line, is that of pomelo. Hybrids of the sweet orange form later types of mandarin and the grapefruit. The sweet orange has had its full genome sequenced.

The orange originated in a region encompassing Southern China, Northeast India, and Myanmar; the earliest mention of the sweet orange was in Chinese literature in 314 BC. Orange trees are widely grown in tropical and subtropical areas for their sweet fruit. The fruit of the orange tree can be eaten fresh or processed for its juice or fragrant peel. In 2022, 76 million tonnes of oranges were grown worldwide, with Brazil producing 22% of the total, followed by India and China.

Oranges, variously understood, have featured in human culture since ancient times. They first appear in Western art in the Arnolfini Portrait by Jan van Eyck, but they had been depicted in Chinese art centuries earlier, as in Zhao Lingrang's Song dynasty fan painting Yellow Oranges and Green Tangerines. By the 17th century, an orangery had become an item of prestige in Europe, as seen at the Versailles Orangerie. More recently, artists such as Vincent van Gogh, John Sloan, and Henri Matisse included oranges in their paintings.

Description
The orange tree is a relatively small evergreen, flowering tree, with an average height of 9 to 10 m (30 to 33 ft), although some very old specimens can reach 15 m (49 ft).[1] Its oval leaves, which are alternately arranged, are 4 to 10 cm (1.6 to 3.9 in) long and have crenulate margins.[2] Sweet oranges grow in a range of different sizes, and shapes varying from spherical to oblong. Inside and attached to the rind is a porous white tissue, the white, bitter mesocarp or albedo (pith).[3] The orange contains a number of distinct carpels (segments or pigs, botanically the fruits) inside, typically about ten, each delimited by a membrane and containing many juice-filled vesicles and usually a few pips. When unripe, the fruit is green. The grainy irregular rind of the ripe fruit can range from bright orange to yellow-orange, but frequently retains green patches or, under warm climate conditions, remains entirely green. Like all other citrus fruits, the sweet orange is non-climacteric, not ripening off the tree. The Citrus sinensis group is subdivided into four classes with distinct characteristics: common oranges, blood or pigmented oranges, navel oranges, and acidless oranges.[4][5][6] The fruit is a hesperidium, a modified berry; it is covered by a rind formed by a rugged thickening of the ovary wall.[7][8]

Flowers
Flowers
 
Fruit starting to develop
Fruit starting to develop
 
Flowers and fruit simultaneously
Flowers and fruit simultaneously
 
Mature tree in Galicia, Spain, fruiting in November
Mature tree in Galicia, Spain, fruiting in November
 Structure of the botanical hesperidium
Structure of the botanical hesperidium
History
Hybrid origins
Citrus trees are angiosperms, and most species are almost entirely interfertile. This includes grapefruits, lemons, limes, oranges, and many citrus hybrids. As the interfertility of oranges and other citrus has produced numerous hybrids and cultivars, and bud mutations have also been selected, citrus taxonomy has proven difficult.[9]

The sweet orange, Citrus x sinensis,[10] is not a wild fruit, but arose in domestication in East Asia. It originated in a region encompassing Southern China, Northeast India,[11] and Myanmar.[12] The fruit was created as a cross between a non-pure mandarin orange and a hybrid pomelo that had a substantial mandarin component.[13][14] Since its chloroplast DNA is that of pomelo, it was likely the hybrid pomelo, perhaps a pomelo BC1 backcross, that was the maternal parent of the first orange.[15][16] Based on genomic analysis, the relative proportions of the ancestral species in the sweet orange are approximately 42% pomelo and 58% mandarin.[17] All varieties of the sweet orange descend from this prototype cross, differing only by mutations selected for during agricultural propagation.[16] Sweet oranges have a distinct origin from the bitter orange, which arose independently, perhaps in the wild, from a cross between pure mandarin and pomelo parents.[16]

Sweet oranges have in turn given rise to many further hybrids including the grapefruit, which arose from a sweet orange x pomelo backcross. Spontaneous and engineered backcrosses between the sweet orange and mandarin oranges or tangerines have produced the clementine and murcott. The ambersweet is a complex sweet orange x (Orlando tangelo x clementine) hybrid.[17][18] The citranges are a group of sweet orange x trifoliate orange (Citrus trifoliata) hybrids.[19]


The orange is a hybrid of mandarin and pomelo.[17]
Arab Agricultural Revolution
Further information: Arab Agricultural Revolution

The Arab Agricultural Revolution spread citrus fruits as far as the Iberian Peninsula. Page from the Hadith Bayad wa Riyad, 13th century
In Europe, the Moors introduced citrus fruits including the bitter orange, lemon, and lime to Al-Andalus in the Iberian Peninsula during the Arab Agricultural Revolution.[20] Large-scale cultivation started in the 10th century, as evidenced by complex irrigation techniques specifically adapted to support orange orchards.[21][20] Citrus fruits—among them the bitter orange—were introduced to Sicily in the 9th century during the period of the Emirate of Sicily, but the sweet orange was unknown there until the late 15th century or the beginnings of the 16th century, when Italian and Portuguese merchants brought orange trees into the Mediterranean area.[11]

Spread across Europe
Shortly afterward, the sweet orange quickly was adopted as an edible fruit. It was considered a luxury food grown by wealthy people in private conservatories, called orangeries. By 1646, the sweet orange was well known throughout Europe; it went on to become the most often cultivated of all fruit trees.[11] Louis XIV of France had a great love of orange trees and built the grandest of all royal Orangeries at the Palace of Versailles.[22] At Versailles, potted orange trees in solid silver tubs were placed throughout the rooms of the palace, while the Orangerie allowed year-round cultivation of the fruit to supply the court. When Louis condemned his finance minister, Nicolas Fouquet, in 1664, part of the treasures that he confiscated were over 1,000 orange trees from Fouquet's estate at Vaux-le-Vicomte.[23]

To the Americas
Further information: Columbian exchange
Spanish travelers introduced the sweet orange to the American continent. On his second voyage in 1493, Christopher Columbus may have planted the fruit on Hispaniola.[6] Subsequent expeditions in the mid-1500s brought sweet oranges to South America and Mexico, and to Florida in 1565, when Pedro Menéndez de Avilés founded St Augustine. Spanish missionaries brought orange trees to Arizona between 1707 and 1710, while the Franciscans did the same in San Diego, California, in 1769.[11] Archibald Menzies, the botanist on the Vancouver Expedition, collected orange seeds in South Africa, raised the seedlings on board, and gave them to several Hawaiian chiefs in 1792. The sweet orange came to be grown across the Hawaiian Islands, but its cultivation stopped after the arrival of the Mediterranean fruit fly in the early 1900s.[11][24] Florida farmers obtained seeds from New Orleans around 1872, after which orange groves were established by grafting the sweet orange on to sour orange rootstocks.[11]

California
Citrus cultivation in California began with the Spanish missionaries, who planted oranges and lemons at Baja California around 1739 and at Alta California missions by 1769. Early fruit was thick-skinned and sour, not suited for commercial markets. The first sizable grove was established at Mission San Gabriel in 1804, with about 400 trees on six acres. This mission-based agriculture ended with secularization which closed the missions and gave away their lands in 1835. Jean-Louis Vignes likely planted the first private orange grove in Los Angeles in 1834. William Wolfskill planted his orchard in Los Angeles in 1841. By 1862, his orchards held two-thirds of the state's orange trees. The California gold rush (from 1849) increased demand for oranges, especially for their vitamin C, which helped prevent scurvy among miners. This spurred gradual expansion of orchards. In the early 1870s, Wolfskill's reported profits of $1,000 per acre attracted Midwestern farmers to citrus growing, especially in Orange County.[25][26]

The 1870s saw the introduction of improved fruit varieties. In 1873, navel orange plants from Brazil were distributed by the U.S. Department of Agriculture. Luther C. Tibbets and Eliza Tibbets successfully cultivated these in Riverside, leading to widespread planting of the sweet, seedless navel orange, which became the backbone of the California citrus industry. The Valencia orange, introduced in 1876, matured in summer and fall, complementing the winter-ripening navel and providing oranges year-round. The completion of major railroads (Southern Pacific in 1877, and the Santa Fe in 1885) and the introduction of ventilated boxcars revolutionized distribution, opening national markets and triggering a planting frenzy in southern California. By 1885, the number of citrus trees in California had grown from 90,000 (in 1875) to 2 million, and to 4.5 million by 1901.[27][28]

The 1890s brought pest control advances (spraying, fumigation) and frost protection (heaters, later wind machines). The University of California established its Citrus Experiment Station in 1907, supporting research and innovation. Cooperative marketing emerged with the formation of the California Fruit Growers Exchange in 1905, later known as Sunkist Growers Inc., which helped standardize and market California citrus worldwide. By the 1980s, California was the second largest orange producer in the U.S., after Florida.[29][30]

Etymology
Main article: Orange (word)
The word "orange" has its etymological roots in the Dravidian language family of South India.[31] From there, the word passed to Sanskrit नारङ्ग (nāraṅga), meaning 'orange tree'. The Sanskrit word reached European languages through Persian نارنگ (nārang) and its Arabic derivative نارنج (nāranj).[32] The word entered Late Middle English in the 14th century via Old French pomme d'orenge.[33] Other forms include Old Provençal auranja,[34] Italian arancia, formerly narancia.[32] In several languages, the initial n present in earlier forms of the word dropped off because it may have been mistaken as part of an indefinite article ending in an n sound. In French, for example, une norenge may have been heard as une orenge. This linguistic change is called juncture loss. The color was named after the fruit,[35] with the first recorded use of orange as a color name in English in 1512.[36][37]


Etymology of 'orange'
Composition
Nutrition
Oranges, raw,
all commercial varieties
Nutritional value per 100 g (3.5 oz)
Energy	197 kJ (47 kcal)
Carbohydrates
11.75 g
Sugars	9.35 g
Dietary fiber	2.4 g
Fat
0.12 g
Protein
0.94 g
Vitamins and minerals
Other constituents	Quantity
Water	87 g
Link to USDA Database entry
†Percentages estimated using US recommendations for adults,[38] except for potassium, which is estimated based on expert recommendation from the National Academies.[39]
Orange flesh is 87% water, 12% carbohydrates, 1% protein, and contains negligible fat (table). In a reference amount of 100 g (3.5 oz), orange flesh provides 47 calories, and is a rich source of vitamin C, providing 59% of the Daily Value, with no other micronutrients in significant amounts (table).

Phytochemicals
Oranges contain diverse phytochemicals, including carotenoids (beta-carotene, lutein and beta-cryptoxanthin), flavonoids (e.g. naringenin)[40] and numerous volatile organic compounds producing orange aroma, including aldehydes, esters, terpenes, alcohols, and ketones.[41] Orange juice contains only about one-fifth the citric acid of lime or lemon juice (which contain about 47 g/L).[42]

Taste

Octyl acetate, a volatile compound contributing to the fragrance of oranges
The taste of oranges is determined mainly by the ratio of sugars to acids, whereas orange aroma derives from volatile organic compounds, including alcohols, aldehydes, ketones, terpenes, and esters.[43][44] Bitter limonoid compounds, such as limonin, decrease gradually during development, whereas volatile aroma compounds tend to peak in mid- to late-season development.[45] Taste quality tends to improve later in harvests when there is a higher sugar/acid ratio with less bitterness.[45] As a citrus fruit, the orange is acidic, with pH levels ranging from 2.9[46] to 4.0.[46][47] Taste and aroma vary according to genetic background, environmental conditions during development, ripeness at harvest, postharvest conditions, and storage duration.[43][44]

Cultivars
Common
Common oranges (also called "white", "round", or "blond" oranges) constitute about two-thirds of all orange production. The majority of this crop is used for juice.[4][6]

Valencia
Main article: Valencia orange
The Valencia orange is a late-season fruit; it is popular when navel oranges are out of season. Thomas Rivers, an English nurseryman, imported this variety from the Azores and catalogued it in 1865 under the name Excelsior. Around 1870, he provided trees to S. B. Parsons, a Long Island nurseryman, who in turn sold them to E. H. Hart of Federal Point, Florida.[48]

Navel
Main article: Navel orange
Navel oranges have a characteristic second fruit at the apex, which protrudes slightly like a human navel. They are mainly an eating fruit, as their thicker skin makes them easy to peel, they are less juicy and their bitterness makes them less suitable for juice.[4] The parent variety was probably the Portuguese navel orange or Umbigo.[49] The cultivar rapidly spread to other countries, but being seedless it had to be propagated by cutting and grafting.[50]

The Cara Cara is a type of navel orange grown mainly in Venezuela, South Africa and California's San Joaquin Valley. It is sweet and low in acid,[51] with distinctively pinkish red flesh. It was discovered at the Hacienda Cara Cara in Valencia, Venezuela, in 1976.[52]

Blood
Main article: Blood orange
Blood oranges, with an intense red coloration inside, are widely grown around the Mediterranean; there are several cultivars.[11] The development of the red color requires cool nights.[53] The redness is mainly due to the anthocyanin pigment chrysanthemin (cyanidin 3-O-glucoside).[54]

Acidless
Acidless oranges are an early-season fruit with very low levels of acid. They also are called "sweet" oranges in the United States, with similar names in other countries: douce in France, sucrena in Spain, dolce or maltese in Italy, meski in North Africa and the Near East (where they are especially popular), succari in Egypt, and lima in Brazil.[4] The lack of acid, which protects orange juice against spoilage in other groups, renders them generally unfit for processing as juice, so they are primarily eaten. They remain profitable in areas of local consumption, but rapid spoilage renders them unsuitable for export to major population centres of Europe, Asia, or the United States.[4]

A grove of Valencia oranges in Florida
A grove of Valencia oranges in Florida
 
Cara Cara navel orange
Cara Cara navel orange
 
Blood orange
Blood orange
Cultivation
Climate
Like most citrus plants, oranges do well under moderate temperatures—between 15.5 and 29 °C (59.9 and 84.2 °F)—and require considerable amounts of sunshine and water. They are principally grown in tropical and subtropical regions.[6]

As oranges are sensitive to frost, farmers have developed methods to protect the trees from frost damage. A common process is to spray the trees with water so as to cover them with a thin layer of ice, insulating them even if air temperatures drop far lower. This practice, however, offers protection only for a very short time.[55] Another procedure involves burning fuel oil in smudge pots put between the trees. These burn with a great deal of particulate emission, so condensation of water vapor on the particulate soot prevents condensation on plants and raises the air temperature very slightly. Smudge pots were developed after a disastrous freeze in southern California in January 1913 destroyed a whole crop.[56]

Propagation
Further information: Fruit tree propagation and Citrus rootstock
Commercially grown orange trees are propagated asexually by grafting a mature cultivar onto a suitable seedling rootstock to ensure the same yield, identical fruit characteristics, and resistance to diseases throughout the years. Propagation involves two stages: first, a rootstock is grown from seed. Then, when it is approximately one year old, the leafy top is cut off and a bud taken from a specific scion variety, is grafted into its bark. The scion is what determines the variety of orange, while the rootstock makes the tree resistant to pests and diseases and adaptable to specific soil and climatic conditions. Thus, rootstocks influence the rate of growth and have an effect on fruit yield and quality.[57] Rootstocks must be compatible with the variety inserted into them because otherwise, the tree may decline, be less productive, or die.[57] Among the advantages to grafting are that trees mature uniformly and begin to bear fruit earlier than those reproduced by seeds (3 to 4 years in contrast with 6 to 7 years),[58] and that farmers can combine the best attributes of a scion with those of a rootstock.[59]

Harvest
Canopy-shaking mechanical harvesters are being used increasingly in Florida to harvest oranges. Current canopy shaker machines use a series of six-to-seven-foot-long tines to shake the tree canopy at a relatively constant stroke and frequency.[60] Oranges are picked once they are pale orange.[61]

Degreening
Oranges must be mature when harvested. In the United States, laws forbid harvesting immature fruit for human consumption in Texas, Arizona, California, and Florida.[62] Ripe oranges, however, often have some green or yellow-green color in the skin. Ethylene gas is used to turn green skin to orange. This process is known as "degreening", "gassing", "sweating", or "curing".[62] Oranges are non-climacteric fruits, and cannot ripen internally in response to ethylene gas after harvesting, though they will de-green externally.[63]

Storage
Commercially, oranges can be stored by refrigeration in controlled-atmosphere chambers for up to twelve weeks after harvest. Storage life ultimately depends on cultivar, maturity, pre-harvest conditions, and handling.[64] At home, oranges have a shelf life of about one month, and are best stored loose.[65]

Spraying oranges in an orchard in Australia
Spraying oranges in an orchard in Australia
 
Orange grove in California
Orange grove in California
 
Picking oranges, Israel
Picking oranges, Israel
 
Harvest, Israel
Harvest, Israel
 Market stall, Morocco
Market stall, Morocco
Pests and diseases
Pests

Cottony cushion scale insects devastated orange groves across California in the 19th century, and were the first pest to be subject to successful biological control.[48]
The first major pest that attacked orange trees in the United States was the cottony cushion scale (Icerya purchasi), imported from Australia to California in 1868. Within 20 years, it wiped out the citrus orchards around Los Angeles, and limited orange growth throughout California. In 1888, the USDA sent Alfred Koebele to Australia to study this scale insect in its native habitat. He brought back with him specimens of an Australian ladybird, Novius cardinalis (the Vedalia beetle), and within a decade the pest was controlled. This was one of the first successful applications of biological pest control on any crop.[48] The orange dog caterpillar of the giant swallowtail butterfly, Papilio cresphontes, is a pest of citrus plantations in North America, where it eats new foliage and can defoliate young trees.[66]

Diseases
Further information: List of citrus diseases

The Asian citrus psyllid, Diaphorina citri, is a major vector of citrus greening disease.[67]
Citrus greening disease, caused by the bacterium Liberobacter asiaticum, has been the most serious threat to orange production since 2010. It is characterized by streaks of different shades on the leaves, and deformed, poorly colored, unsavory fruit. In areas where the disease is endemic, citrus trees live for only five to eight years and never bear fruit suitable for consumption.[68] In the western hemisphere, the disease was discovered in Florida in 1998, where it has attacked nearly all the trees ever since. It was reported in Brazil by Fundecitrus Brasil in 2004.[68] As from 2009, 0.87% of the trees in Brazil's main orange growing areas (São Paulo and Minas Gerais) showed symptoms of greening, an increase of 49% over 2008.[69] The disease is spread primarily by psyllid plant lice such as the Asian citrus psyllid (Diaphorina citri Kuwayama), an efficient vector of the bacterium.[67] Foliar insecticides reduce psyllid populations for a short time, but also suppress beneficial predatory ladybird beetles. Soil application of aldicarb provided limited control of Asian citrus psyllid, while drenches of imidacloprid to young trees were effective for two months or more.[70] Management of citrus greening disease requires an integrated approach that includes use of clean stock, elimination of inoculum via voluntary and regulatory means, use of pesticides to control psyllid vectors in the citrus crop, and biological control of the vectors in non-crop reservoirs.[68]

Greasy spot, a fungal disease caused by the ascomycete Mycosphaerella citri, produces leaf spots and premature defoliation, thus reducing the tree's vigour and yield. Ascospores of M. citri are generated in pseudothecia in decomposing fallen leaves.[71]

Production

Orange production
Production – 2022
(millions of tonnes)
 Brazil	16.9
 India	10.2
‹See TfM› China	7.6
 Mexico	4.8
 Egypt	3.4
 United States	3.1
World	76.4
Source: FAOSTAT
of the United Nations[72]
Main article: Citrus production
In 2022, world production of oranges was 76 million tonnes, led by Brazil with 22% of the total, followed by India, China, and Mexico.[72] The United States Department of Agriculture has established grades for Florida oranges, primarily for oranges sold as fresh fruit.[73] In the United States, groves are located mainly in Florida, California, and Texas.[74] The majority of California's crop is sold as fresh fruit, whereas Florida's oranges are destined to juice products. The Indian River area of Florida produces high quality juice, which is often sold fresh and blended with juice from other regions, because Indian River trees yield sweet oranges but in relatively small quantities.[75]

Culinary use
Dessert fruit and juice
Further information: Orange juice
Oranges, whose flavor may vary from sweet to sour, are commonly peeled and eaten fresh raw as a dessert. Orange juice is obtained by squeezing the fruit on a special tool (a juicer or squeezer) and collecting the juice in a tray or tank underneath. This can be made at home or, on a much larger scale, industrially.[76] Orange juice is a traded commodity on the Intercontinental Exchange.[77] Frozen orange juice concentrate is made from freshly squeezed and filtered juice.[78]

Marmalade
Main article: Marmalade
Oranges are made into jam in many countries; in Britain, bitter Seville oranges are used to make marmalade. Almost the whole Spanish production is exported to Britain for this purpose. The entire fruit is cut up and boiled with sugar; the pith contributes pectin, which helps the marmalade to set. The first recipe was by an Englishwoman, Mary Kettilby, in 1714. Pieces of peel were first added by Janet Keiller of Dundee in the 1790s, contributing a distinctively bitter taste.[79] Orange peel contains the bitter substances limonene and naringin.[80][81]

Extracts
Further information: Limonene
Zest is scraped from the coloured outer part of the peel, and used as a flavoring and garnish in desserts and cocktails.[82]

Sweet orange oil is a by-product of the juice industry produced by pressing the peel. It is used for flavoring food and drinks; it is employed in the perfume industry and in aromatherapy for its fragrance. The oil consists of approximately 90% D-limonene, a solvent used in household chemicals such as wood conditioners for furniture and—along with other citrus oils—detergents and hand cleansers. It is an efficient cleaning agent with a pleasant smell, promoted for being environmentally friendly and therefore preferable to petrochemicals. It is, however, irritating to the skin and toxic to aquatic life.[83][84]

Fruit and juice
Fruit and juice
 
Zesting an orange
Zesting an orange
 
Homemade marmalade, England
Homemade marmalade, England
In human culture
Oranges have featured in human culture since ancient times. The earliest mention of the sweet orange in Chinese literature dates from 314 BC.[13] Larissa Pham, in The Paris Review, notes that sweet oranges were available in China much earlier than in the West. She writes that Zhao Lingrang's fan painting Yellow Oranges and Green Tangerines pays attention not to the fruit's colour but the shape of the fruit-laden trees, and that Su Shi's poem on the same subject runs "You must remember, / the best scenery of the year, / Is exactly now, / when oranges turn yellow and tangerines green."[85]

The scholar Cristina Mazzoni has examined the multiple uses of the fruit in Italian art and literature, from Catherine of Siena's sending of candied oranges to Pope Urban, to Sandro Botticelli's setting of his painting Primavera in an orange grove. She notes that oranges symbolised desire and wealth on the one hand, and deformity on the other, while in the fairy-stories of Sicily, they have magical properties.[86] Pham comments that the Arnolfini Portrait by Jan van Eyck contains in a small detail one of the first representations of oranges in Western art, the costly fruit perhaps traded by the merchant Arnolfini himself.[85] By the 17th century, orangeries were added to great houses in Europe, both to enable the fruit to be grown locally and for prestige, as seen in the Versailles Orangerie completed in 1686.[87]

The Dutch Post-Impressionist artist Vincent van Gogh portrayed oranges in paintings such as his 1889 Still Life of Oranges and Lemons with Blue Gloves and his 1890 A Child with Orange, both works late in his life. The American artist of the Ashcan School, John Sloan, made a 1935 painting Blond Nude with Orange, Blue Couch, while Henri Matisse's last painting was his 1951 Nude with Oranges; after that he only made cut-outs.[88]

Yellow Oranges and Green Tangerines by Zhao Lingrang, Chinese fan painting from the Song dynasty, c. 1070–1100
Yellow Oranges and Green Tangerines by Zhao Lingrang, Chinese fan painting from the Song dynasty, c. 1070–1100
 
Detail of the Arnolfini Portrait by Jan van Eyck, 1434
Detail of the Arnolfini Portrait by Jan van Eyck, 1434
 
Detail of Primavera by Sandro Botticelli, 1482, set in an orange grove
Detail of Primavera by Sandro Botticelli, 1482, set in an orange grove
 
Still life with oranges on a plate. Possibly Jacques Linard or Louise Moillon, 1640
Still life with oranges on a plate. Possibly Jacques Linard or Louise Moillon, 1640
 The Versailles Orangerie, 1686
The Versailles Orangerie, 1686
 
Jean-Baptiste Oudry, The Orange Tree, 1740
Jean-Baptiste Oudry, The Orange Tree, 1740
 
Still Life of Oranges and Lemons with Blue Gloves by Vincent van Gogh, 1889
Still Life of Oranges and Lemons with Blue Gloves by Vincent van Gogh, 1889
See also
List of citrus fruits
List of culinary fruits
References
 Hodgson, Willard (1967–1989) [1943]. "Chapter 4: Horticultural Varieties of Citrus". In Webber, Herbert John; rev Walter Reuther and Harry W. Lawton (eds.). The Citrus Industry. Riverside, California: University of California Division of Agricultural Sciences. Archived from the original on 2012-02-05.
 "Sweet Orange – Citrus sinensis (L.) Osbeck (pro. sp.) – Overview – Encyclopedia of Life". Encyclopedia of Life. Archived from the original on 2010-12-04. Retrieved 2011-01-18.
 "Pith dictionary definition – pith defined". www.yourdictionary.com. Archived from the original on 2011-05-12. Retrieved 2011-01-17.
 Kimball, Dan A. (June 30, 1999). Citrus processing: a complete guide (2d ed.). New York: Springer. p. 450. ISBN 978-0-8342-1258-9.
 Webber, Herbert John; Reuther, Walter; Lawton, Harry W. (1967–1989) [1903]. "The Citrus Industry". Riverside, California: University of California Division of Agricultural Sciences. Archived from the original on 2004-06-04.
 Sauls, Julian W. (December 1998). "Home Fruit Production – Oranges". Texas A&M University. Archived from the original on 10 May 2023. Retrieved 30 November 2012.
 Bailey, H. and Bailey, E. (1976). Hortus Third. Cornell University MacMillan. N.Y. p. 275.
 "Seed and Fruits". esu.edu. Archived from the original on 2010-11-14.
 Nicolosi, E.; Deng, Z. N.; Gentile, A.; La Malfa, S.; Continella, G.; Tribulato, E. (2000). "Citrus phylogeny and genetic origin of important species as investigated by molecular markers". Theoretical and Applied Genetics. 100 (8): 1155–1166. doi:10.1007/s001220051419. S2CID 24057066.
 "Citrus ×sinensis (L.) Osbeck (pro sp.) (maxima × reticulata) sweet orange". Plants.USDA.gov. Archived from the original on May 12, 2011.
 Morton, Julia F. (1987). Fruits of Warm Climates. pp. 134–142. Archived from the original on 2019-05-26. Retrieved 2020-05-05.
 Talon, Manuel; Caruso, Marco; Gmitter, Fred G. Jr. (2020). The Genus Citrus. Woodhead Publishing. p. 17. ISBN 978-0-12-812217-4. Archived from the original on 2024-03-16. Retrieved 2020-05-05.
 Xu, Q.; Chen, L.L.; Ruan, X.; Chen, D.; Zhu, A.; Chen, C.; et al. (Jan 2013). "The draft genome of sweet orange (Citrus sinensis)". Nature Genetics. 45 (1): 59–66. doi:10.1038/ng.2472. PMID 23179022.
 Andrés García Lor (2013). Organización de la diversidad genética de los cítricos (PDF) (Thesis). p. 79. Archived (PDF) from the original on 2021-02-25. Retrieved 2015-04-24.
 Velasco, R.; Licciardello, C. (2014). "A genealogy of the citrus family". Nature Biotechnology. 32 (7): 640–642. doi:10.1038/nbt.2954. PMID 25004231. S2CID 9357494.
 Wu, G. Albert (2014). "Sequencing of diverse mandarin, pomelo and orange genomes reveals complex history of admixture during citrus domestication". Nature Biotechnology. 32 (7): 656–662. doi:10.1038/nbt.2906. PMC 4113729. PMID 24908277.
 Wu, Guohong Albert; Terol, Javier; Ibanez, Victoria; López-García, Antonio; Pérez-Román, Estela; Borredá, Carles; et al. (2018). "Genomics of the origin and evolution of Citrus". Nature. 554 (7692): 311–316. Bibcode:2018Natur.554..311W. doi:10.1038/nature25447. hdl:20.500.11939/5741. PMID 29414943. and Supplement
 Bai, Jinhe; Baldwin, Elizabeth B.; Hearn, Jake; Driggers, Randy; Stover, Ed (2014). "Volatile Profile Comparison of USDA Sweet Orange-like Hybrids versus 'Hamlin' and 'Ambersweet'". HortScience. 49 (10): 1262–1267. doi:10.21273/HORTSCI.49.10.1262. Archived from the original on 2016-07-21. Retrieved 2018-03-18.
 "Trifoliate hybrids". University of California at Riverside, Givaudan Citrus Variety Collection. Archived from the original on 20 January 2022. Retrieved 15 March 2024.
 Watson, Andrew M. (1974). "The Arab Agricultural Revolution and Its Diffusion, 700–1100". The Journal of Economic History. 34 (1): 8–35. doi:10.1017/S0022050700079602. JSTOR 2116954. S2CID 154359726.
 Trillo San José, Carmen (1 September 2003). "Water and landscape in Granada". University of Granada. Archived from the original on 8 March 2023. Retrieved 7 January 2017.
 Leroux, Jean-Baptiste (2002). The Gardens of Versailles. Thames & Hudson. p. 368.
 Mitford, Nancy (1966). The Sun King. Sphere Books. p. 11.
 Mau, Ronald; Kessing, Jayma Martin (April 2007). "Ceratitis capitata (Wiedemann)". University of Hawaii. Archived from the original on 18 July 2012. Retrieved 5 December 2012.
 James D. Hart, A Companion to California (1987). p. 91.
 Ching Lee, "The history of citrus in California" California Bountiful (2022) online
 Clifford M. Zierer, "The citrus fruit industry of the Los Angeles basin." Economic Geography 10.1 (1934): 53-73. online Archived 2017-10-26 at the Wayback Machine
 Daniel Geisseler, and William R. Horwath, "Citrus production in California." (2016), online
 Lee, "The history of citrus in California"
 Ronald Tobey, and Charles Wetherell, "The Citrus Industry and the Revolution of Corporate Capitalism in Southern California, 1887-1944." California History 74.1 (1995): 6-21. JSTOR 25177466
 Mayrhofer, Manfred (2001). "orange". Etymologisches Wörterbuch des Altindoarischen [Etymological Dictionary of Old Indo-Aryan] (in German). Vol. 3. Heidelberg: Carl Winter Universitätsverlag. p. 287.
 "orange (n.)". Online Etymology Dictionary. Archived from the original on 21 February 2024. Retrieved 15 March 2024.
 "Definition of orange". OED online (www.oxforddictionaries.com). Archived from the original on May 11, 2013.
 "Definition of orange". Collins English Dictionary (collinsdictionary.com). Archived from the original on 2013-04-03. Retrieved 2012-12-05.
 Paterson, Ian (2003). A Dictionary of Colour: A Lexicon of the Language of Colour (1st paperback ed.). London: Thorogood (published 2004). p. 280. ISBN 978-1-85418-375-0. OCLC 60411025.
 "orange colour". Oxford English Dictionary (Online ed.). Oxford University Press. (Subscription or participating institution membership required.)
 Maerz, Aloys John; Morris, Rea Paul (1930), A Dictionary of Color, New York: McGraw-Hill, p. 200
 United States Food and Drug Administration (2024). "Daily Value on the Nutrition and Supplement Facts Labels". FDA. Archived from the original on 2024-03-27. Retrieved 2024-03-28.
 "TABLE 4-7 Comparison of Potassium Adequate Intakes Established in This Report to Potassium Adequate Intakes Established in the 2005 DRI Report". p. 120. In: Stallings, Virginia A.; Harrison, Meghan; Oria, Maria, eds. (2019). "Potassium: Dietary Reference Intakes for Adequacy". Dietary Reference Intakes for Sodium and Potassium. pp. 101–124. doi:10.17226/25353. ISBN 978-0-309-48834-1. PMID 30844154. NCBI NBK545428.
 Aschoff, Julian K.; Kaufmann, Sabrina; Kalkan, Onur; Neidhart, Sybille; Carle, Reinhold; Schweiggert, Ralf M. (2015-01-21). "In Vitro Bioaccessibility of Carotenoids, Flavonoids, and Vitamin C from Differently Processed Oranges and Orange Juices [ Citrus sinensis (L.) Osbeck]". Journal of Agricultural and Food Chemistry. 63 (2): 578–587. Bibcode:2015JAFC...63..578A. doi:10.1021/jf505297t. ISSN 0021-8561. PMID 25539394.
 Perez-Cacho, P.R.; Rouseff, R.L. (2008). "Fresh squeezed orange juice odor: a review". Crit Rev Food Sci Nutr. 48 (7): 681–95. Bibcode:2008CRFSN..48..681P. doi:10.1080/10408390701638902. PMID 18663618. S2CID 32567584.
 Penniston, Kristina L.; Nakada, Stephen Y.; Holmes, Ross P.; Assimos, Dean G. (2008). "Quantitative Assessment of Citric Acid in Lemon Juice, Lime Juice, and Commercially-Available Fruit Juice Products". Journal of Endourology. 22 (3): 567–570. doi:10.1089/end.2007.0304. ISSN 0892-7790. PMC 2637791. PMID 18290732.
 Tietel, Z.; Plotto, A.; Fallik, E.; Lewinsohn, E.; Porat, R. (2011). "Taste and aroma of fresh and stored mandarins". Journal of the Science of Food and Agriculture. 91 (1): 14–23. Bibcode:2011JSFA...91...14T. doi:10.1002/jsfa.4146. PMID 20812381.
 El Hadi, M. A.; Zhang, F. J.; Wu, F. F.; Zhou, C. H.; Tao, J (2013). "Advances in fruit aroma volatile research". Molecules. 18 (7): 8200–29. doi:10.3390/molecules18078200. PMC 6270112. PMID 23852166.
 Bai, J.; Baldwin, E. A.; McCollum, G.; Plotto, A.; Manthey, J. A.; Widmer, W. W.; Luzio, G.; Cameron, R. (2016). "Changes in Volatile and Non-Volatile Flavor Chemicals of "Valencia" Orange Juice over the Harvest Seasons". Foods. 5 (1): 4. doi:10.3390/foods5010004. PMC 5224568. PMID 28231099.
 Sinclair, Walton B.; Bartholomew, E.T.; Ramsey, R. C. (1945). "Analysis of the organic acids of orange juice" (PDF). Plant Physiology. 20 (1): 3–18. doi:10.1104/pp.20.1.3. PMC 437693. PMID 16653966.
 Centers for Disease Control and Prevention (July 16, 1999). "Outbreak of Salmonella Serotype Muenchen Infections Associated with Unpasteurized Orange Juice – United States and Canada, June 1999". Morbidity and Mortality Weekly Report. 48 (27): 582–585. PMID 10428096. Archived from the original on November 1, 2021. Retrieved September 10, 2017.
 Coit, John Eliot (1915). Citrus fruits: an account of the citrus fruit industry, with special reference to California requirements and practices and similar conditions. Macmillan. Retrieved 2 October 2011.
 "Washington". Citrus ID. Archived from the original on 14 March 2024. Retrieved 14 March 2024., citing amongst other sources Risso, A.; Poiteau, A. (1819–1822). Histoire Naturelle des Orangers. Paris: Audot. Archived from the original on 2023-12-10. Retrieved 2024-03-14.
 "Commodity Fact Sheet: Citrus Fruits" (PDF). California Foundation for Agriculture in the Classroom. Archived (PDF) from the original on 16 August 2022. Retrieved 14 March 2024.
 "UBC Botanical Garden, Botany Photo of the Day". Archived from the original on 2010-01-24.
 "Cara Cara navel orange". University of California, Riverside. Archived from the original on 2019-04-25. Retrieved January 15, 2026.
 McGee, Harold (2004). On food and cooking: the science and lore of the kitchen. New York: Scribner. p. 376. ISBN 0-684-80001-2. Archived from the original on 2023-07-28. Retrieved 2024-03-15.
 Felgines, C.; Texier, O.; Besson, C.; Vitaglione, P; Lamaison, J.-L.; Fogliano, V.; et al. (2008). "Influence of glucose on cyanidin 3-glucoside absorption in rats". Molecular Nutrition & Food Research. 52 (8): 959–64. doi:10.1002/mnfr.200700377. PMID 18646002.
 "How Cold Can Water Get?". Argonne National Laboratory. 2002-09-08. Archived from the original on 2015-02-26. Retrieved 2009-04-16.
 Moore, Frank Ensor (1995). Redlands Astride the Freeway: The Development of Good Automobile Roads. Redlands, California: Moore Historical Foundation. p. 9. ISBN 978-0-914167-07-5.
 Lacey, Kevin (July 2012). "Citrus rootstocks for WA" (PDF). Government of WA. Department of Agriculture and Food. Archived from the original (PDF) on 2013-11-12. Retrieved 30 November 2012.
 Price, Martin. "Citrus Propagation and Rootstocks". ultimatecitrus.com. Archived from the original on 6 April 2018. Retrieved 30 November 2012.
 "Citrus Propagation. Research Program on Citrus Rootstock Breeding and Genetics". ars-grin.gov. Archived from the original on 2010-05-28.
 Bora, G.; Hebel, M.; Lee, K. (2007-12-01). "In-situ measurement of the detachment force of individual oranges harvested by a canopy shaker harvesting machine" (PDF). Abstracts for the 2007 Joint Annual Meeting of the Florida State Horticulture Society. S2CID 113761794. Archived from the original (PDF) on 2011-07-26.
 "Fresh Citrus Direct". freshcitrusdirect.wordpress.com. Archived from the original on 2015-01-10.
 Wagner, Alfred B.; Sauls, Julian W. "Harvesting and Pre-pack Handling". The Texas A&M University System. Archived from the original on 4 January 2013. Retrieved 29 November 2012.
 Arpaia, Mary Lu; Kader, Adel A. "Orange: Recommendations for Maintaining Postharvest Quality". UCDavis Postharvest Technology Center. Archived from the original on 2013-12-06. Retrieved 2013-12-12.
 Ritenour, M.A. (2004). "Orange. The Commercial Storage of Fruits, Vegetables, and Florist and Nursery Stocks" (PDF). USDA. Archived from the original (PDF) on 2012-01-27.
 "Home Storage Guide for Fresh Fruits & Vegetables. Canadian Produce Marketing Association" (PDF). cpma.ca. Archived from the original (PDF) on 2013-05-12.
 Mcauslane, Heather (May 2009). "Giant Swallowtail, Orangedog, Papilio cresphontes Cramer (Insecta: Lepidoptera: Papilionidae)". Edis (4). University of Florida. doi:10.32473/edis-in134-2009. Archived from the original on 16 March 2024. Retrieved 14 March 2024.
 Killiny, Nabil; Nehela, Yasser; George, Justin; Rashidi, Mahnaz; Stelinski, Lukasz L.; Lapointe, Stephen L. (2021-07-01). "Phytoene desaturase-silenced citrus as a trap crop with multiple cues to attract Diaphorina citri, the vector of Huanglongbing". Plant Science. 308 110930. Bibcode:2021PlnSc.30810930K. doi:10.1016/j.plantsci.2021.110930. ISSN 0168-9452. PMID 34034878. S2CID 235203508.
 Halbert, Susan E.; Manjunath, Keremane L. (September 2004). "Asian citrus psyllids (Sternorrhyncha: Psyllidae) and greening disease of citrus: A literature review and assessment of risk in Florida". The Florida Entomologist. 87 (3): 330–353. doi:10.1653/0015-4040(2004)087[0330:ACPSPA]2.0.CO;2. ISSN 0015-4040. S2CID 56161727.
 "GAIN Report Number: BR9006" (PDF). USDA Foreign Agricultural Service. 18 June 2009. Archived from the original (PDF) on 2011-05-13.
 Qureshi, J.; Stansly, P. (2007-12-01). "Integrated approaches for managing the Asian citrus psyllid Diaphorina citri (Homoptera: Psyllidae) in Florida" (PDF). Proceedings of the Florida State Horticultural Society. 120: 110–115. S2CID 55798062. Archived (PDF) from the original on 2023-11-17. Retrieved 2023-11-17.
 Mondal, S.N.; Morgan, K.T.; Timme, L.W. (June 2007). "Effect of Water Management and Soil Application of Nitrogen Fertilizers, Petroleum Oils, and Lime on Inoculum Production by Mycosphaerella citri, the Cause of Citrus Greasy Spot" (PDF). Abstracts for the 2007 Joint Annual Meeting of the Florida State Horticulture Society. S2CID 113761794. Archived from the original (PDF) on 2011-07-26.
 "Orange production in 2022, Crops/Regions/World list/Production Quantity/Year (pick lists)". UN Food and Agriculture Organization, Corporate Statistical Database. 2024. Archived from the original on 12 November 2016. Retrieved 15 March 2024.
 "United States Standards for Grades of Florida Oranges and Tangelos". USDA. February 1997. Archived from the original on 2011-07-26.
 "Oranges: Production Map by State". United States Department of Agriculture. 1 March 2017. Archived from the original on 31 October 2021. Retrieved 1 April 2017.
 "History of the Indian River Citrus District". Indian River Citrus League. Archived from the original on 1 November 2021. Retrieved 27 November 2012.
 "How orange juice is made". Discovery Networks International. 20 September 2022. Archived from the original on 24 September 2023. Retrieved 16 March 2024.
 Lawson, Alex (27 October 2023). "The great orange juice trading rally – and why a big squeeze could lie ahead". The Guardian. Archived from the original on 22 November 2023. Retrieved 16 March 2024.
 Townsend, Chet (2012). "The Story of Florida Orange Juice: From the Grove to Your Glass". Archived from the original on 18 April 2021. Retrieved 14 March 2024.
 Bateman, Michael (3 January 1993). "Hail marmalade, great chieftain o' the jammy race: Mrs Keiller of Dundee added chunks in the 1790s, thus finally defining a uniquely British gift to gastronomy". The Independent. Archived from the original on 23 February 2016. Retrieved 15 March 2024.
 Barros, H.R.; Ferreira, T.A.; Genovese, M.I. (2012). "Antioxidant capacity and mineral content of pulp and peel from commercial cultivars of citrus from Brazil". Food Chemistry. 134 (4): 1892–8. Bibcode:2012FoodC.134.1892B. doi:10.1016/j.foodchem.2012.03.090. PMID 23442635.
 Hasegawa, S.; Berhow, M. A.; Fong, C. H. (1996). "Analysis of Bitter Principles in Citrus". Fruit Analysis. Vol. 18. Berlin, Heidelberg: Springer. pp. 59–80. doi:10.1007/978-3-642-79660-9_4. ISBN 978-3-642-79662-3.
 Bender, David (2009). Oxford Dictionary of Food and Nutrition (third ed.). Oxford University Press. p. 215. ISBN 978-0-19-923487-5.
 "D-Limonene". International Programme on Chemical Safety. April 2005. Archived from the original on 2021-11-04. Retrieved 2010-03-06.
 "(±)-1-methyl-4-(1-methylvinyl)cyclohexene". ECHA. January 2019. Archived from the original on 2020-10-29. Retrieved 2019-01-22.
 Pham, Larissa (13 August 2019). "For the Love of Orange". The Paris Review. Archived from the original on 14 March 2024. Retrieved 14 March 2024.
 Freedman, Paul (2019). "Review of Golden Fruit: A Cultural History of Oranges in Italy, by Cristina Mazzoni". Journal of Interdisciplinary History. 50 (1). Project MUSE: 129–130. doi:10.1162/jinh_r_01387.
 Thacker, Christopher; Louis XIV (1972). ""La Manière de montrer les jardins de Versailles," by Louis XIV and Others". Garden History. 1 (1): 49–69. doi:10.2307/1586442. ISSN 0307-1243. JSTOR 1586442.
 Michalska, Magda (23 December 2023). "The Scent of Orange in the Air: Paintings with Oranges". Daily Art Magazine. Archived from the original on 14 March 2024. Retrieved 14 March 2024.
External links

Wikiquote has quotations related to Oranges.

Look up orange in Wiktionary, the free dictionary.

Wikibooks Cookbook has a recipe/module on
Orange
 Media related to Citrus sinensis at Wikimedia Commons
 Data related to Citrus sinensis at Wikispecies
Citrus sinensis List of Chemicals (Dr. Duke's Phytochemical and Ethnobotanical Databases), USDA, Agricultural Research Service.
Oranges: Safe Methods to Store, Preserve, and Enjoy. (2006). University of California Agriculture and Natural Resources.
vte
Citrus
vte
State flowers of the United States
Authority control databases Edit this at Wikidata
Categories: Oranges (fruit)Cocktail garnishesCrops originating from ChinaFruits originating in AsiaSymbols of CaliforniaSymbols of FloridaTropical agriculture
This page was last edited on 21 January 2026, at 05:27 (UTC).
Text is available under the Creative Commons Attribution-ShareAlike 4.0 License; additional terms may apply. By using this site, you agree to the Terms of Use and Privacy Policy. Wikipedia® is a registered trademark of the Wikimedia Foundation, Inc., a non-profit organization.
Privacy policyAbout WikipediaDisclaimersContact WikipediaLegal & safety contactsCode of ConductDevelopersStatisticsCookie statementMobile view
Wikimedia Foundation
Powered by MediaWiki
